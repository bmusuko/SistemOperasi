Kami mengupload file kedua kalinya karena kami mendapat tambahan waktu.
Jadi menurut kami, kami dapat mengupload kembali file kami yang lebih baik dan lebih benar
Terima kasih atas pengertian.

13517032
13517089
13517128